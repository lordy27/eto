#!/bin/bash

# Create a temporary directory for the project
mkdir -p temp_project

# Copy necessary files and directories
cp -r src/ temp_project/
cp -r prisma/ temp_project/
cp package.json temp_project/
cp README.md temp_project/
cp .env.example temp_project/
cp next.config.js temp_project/
cp postcss.config.js temp_project/
cp tailwind.config.js temp_project/
cp tsconfig.json temp_project/

# Create the zip file
zip -r inventory-system.zip temp_project/*

# Clean up
rm -rf temp_project

echo "Created inventory-system.zip with all project files"
