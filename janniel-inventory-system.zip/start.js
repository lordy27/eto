const { exec } = require('child_process');
const open = require('open');

// Start the Next.js development server
const server = exec('npm run dev', (error, stdout, stderr) => {
  if (error) {
    console.error(`Error: ${error}`);
    return;
  }
  console.log(`stdout: ${stdout}`);
  console.error(`stderr: ${stderr}`);
});

// Wait for the server to start (3 seconds) then open the browser
setTimeout(async () => {
  try {
    console.log('Opening browser...');
    await open('http://localhost:8000');
  } catch (err) {
    console.error('Error opening browser:', err);
  }
}, 3000);

// Handle server process output
server.stdout.on('data', (data) => {
  console.log(data.toString());
});

server.stderr.on('data', (data) => {
  console.error(data.toString());
});

// Handle process termination
process.on('SIGINT', () => {
  server.kill();
  process.exit();
});
