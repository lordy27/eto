const builder = require('electron-builder');
const Platform = builder.Platform;

builder.build({
  targets: Platform.WINDOWS.createTarget(),
  config: {
    asar: true,
    appId: 'com.jannielbrothers.inventory',
    productName: 'Janniel Brothers Inventory',
    files: [
      "**/*",
      "!**/.git/*",
      "!**/node_modules/*",
      "!dist/*",
      "!build/*"
    ],
    extraResources: [
      {
        "from": ".next",
        "to": ".next"
      },
      {
        "from": "node_modules",
        "to": "node_modules"
      }
    ],
    win: {
      target: ['nsis', 'portable'],
      artifactName: "${productName}-Setup.${ext}"
    },
    nsis: {
      oneClick: false,
      allowToChangeInstallationDirectory: true,
      createDesktopShortcut: true,
      createStartMenuShortcut: true,
      shortcutName: 'Janniel Brothers Inventory'
    },
    directories: {
      output: 'dist'
    }
  }
}).then(() => {
  console.log('Build completed!');
}).catch((error) => {
  console.error('Build failed:', error);
});
