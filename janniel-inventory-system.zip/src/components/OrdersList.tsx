"use client";

import { useState, ChangeEvent } from "react";
import { useInventory } from "@/context/InventoryContext";
import { Button } from "@/components/ui/button";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Input } from "@/components/ui/input";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { OrderForm } from "@/components/OrderForm";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";

export function OrdersList() {
  const { orders, deleteOrder, loading, error } = useInventory();
  const [searchQuery, setSearchQuery] = useState("");

  const filteredOrders = orders.filter(order => 
    order.company.toLowerCase().includes(searchQuery.toLowerCase()) ||
    order.items.some(item => 
      item.product.name.toLowerCase().includes(searchQuery.toLowerCase())
    )
  );

  if (error) {
    return (
      <Alert variant="destructive" className="bg-red-50 border-red-200">
        <AlertDescription className="text-red-600">{error}</AlertDescription>
      </Alert>
    );
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center py-8">
        <div className="flex items-center space-x-2 text-blue-600">
          <div className="w-2 h-2 rounded-full animate-bounce [animation-delay:-0.3s] bg-blue-600"></div>
          <div className="w-2 h-2 rounded-full animate-bounce [animation-delay:-0.15s] bg-blue-600"></div>
          <div className="w-2 h-2 rounded-full animate-bounce bg-blue-600"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="bg-white rounded-xl shadow-lg p-6">
        <div className="flex justify-between items-center">
          <div className="flex items-center gap-6">
            <div>
              <h2 className="text-2xl font-bold bg-gradient-to-r from-green-600 to-green-400 bg-clip-text text-transparent">
                Orders
              </h2>
              <p className="text-gray-500 mt-1">Track and manage your orders</p>
            </div>
            <div className="w-80">
              <div className="relative">
                <Input
                  type="search"
                  placeholder="Search orders by company or product..."
                  value={searchQuery}
                  onChange={(e: ChangeEvent<HTMLInputElement>) => setSearchQuery(e.target.value)}
                  className="pl-10 border-gray-200 focus:border-green-300 focus:ring-2 focus:ring-green-100 transition-all duration-200"
                />
                <svg
                  className="absolute left-3 top-2.5 h-5 w-5 text-gray-400"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth="2"
                    d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"
                  />
                </svg>
              </div>
            </div>
          </div>
          <Dialog>
            <DialogTrigger asChild>
              <Button className="bg-gradient-to-r from-green-600 to-green-500 hover:from-green-700 hover:to-green-600 transition-all duration-200 shadow-md hover:shadow-lg">
                New Order
              </Button>
            </DialogTrigger>
            <DialogContent className="bg-white rounded-xl shadow-2xl">
              <DialogHeader>
                <DialogTitle className="text-2xl font-bold bg-gradient-to-r from-green-600 to-green-400 bg-clip-text text-transparent">
                  Create New Order
                </DialogTitle>
              </DialogHeader>
              <OrderForm onClose={() => {}} />
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {orders.length === 0 ? (
        <div className="bg-white rounded-xl shadow-lg p-12 text-center">
          <p className="text-gray-500 text-lg">
            No orders yet. Create your first order to get started.
          </p>
        </div>
      ) : (
        <div className="bg-white rounded-xl shadow-lg p-6 overflow-hidden">
          <Table>
            <TableHeader>
              <TableRow className="bg-gradient-to-r from-green-50 to-white border-b-2 border-green-100">
                <TableHead className="font-bold text-green-600">Date</TableHead>
                <TableHead className="font-bold text-green-600">Company</TableHead>
                <TableHead className="font-bold text-green-600">Items</TableHead>
                <TableHead className="font-bold text-green-600">Total Quantity</TableHead>
                <TableHead className="font-bold text-green-600">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredOrders.map((order) => (
                <TableRow key={order.id} className="hover:bg-green-50 transition-colors duration-200">
                  <TableCell className="font-medium">
                    {new Date(order.date).toLocaleDateString()}
                  </TableCell>
                  <TableCell>{order.company}</TableCell>
                  <TableCell>
                    <ul className="list-disc list-inside space-y-1">
                      {order.items.map((item) => (
                        <li key={item.id} className="text-gray-600">
                          <span className="font-medium text-gray-900">{item.product.name}</span>
                          {" - "}
                          <span className="text-green-600">{item.qty} units</span>
                        </li>
                      ))}
                    </ul>
                  </TableCell>
                  <TableCell className="font-bold text-green-600">
                    {order.items.reduce((total, item) => total + item.qty, 0)}
                  </TableCell>
                  <TableCell className="space-x-2">
                    <Dialog>
                      <DialogTrigger asChild>
                        <Button 
                          variant="outline" 
                          size="sm"
                          className="bg-white hover:bg-green-50 text-green-600 border-green-200 hover:border-green-300 transition-colors duration-200"
                        >
                          Edit
                        </Button>
                      </DialogTrigger>
                      <DialogContent className="bg-white rounded-xl shadow-2xl">
                        <DialogHeader>
                          <DialogTitle className="text-2xl font-bold bg-gradient-to-r from-green-600 to-green-400 bg-clip-text text-transparent">
                            Edit Order
                          </DialogTitle>
                        </DialogHeader>
                        <OrderForm
                          orderId={order.id}
                          onClose={() => {}}
                        />
                      </DialogContent>
                    </Dialog>

                    <AlertDialog>
                      <AlertDialogTrigger asChild>
                        <Button 
                          variant="destructive" 
                          size="sm"
                          className="bg-red-500 hover:bg-red-600 transition-colors duration-200"
                        >
                          Delete
                        </Button>
                      </AlertDialogTrigger>
                      <AlertDialogContent className="bg-white rounded-xl shadow-2xl">
                        <AlertDialogHeader>
                          <AlertDialogTitle className="text-2xl font-bold text-red-600">
                            Are you sure?
                          </AlertDialogTitle>
                          <AlertDialogDescription className="text-gray-600">
                            This action cannot be undone. This will permanently delete
                            the order and all its items.
                          </AlertDialogDescription>
                        </AlertDialogHeader>
                        <AlertDialogFooter>
                          <AlertDialogCancel className="hover:bg-gray-100 transition-colors duration-200">
                            Cancel
                          </AlertDialogCancel>
                          <AlertDialogAction
                            onClick={() => deleteOrder(order.id)}
                            className="bg-red-500 hover:bg-red-600 transition-colors duration-200"
                          >
                            Delete
                          </AlertDialogAction>
                        </AlertDialogFooter>
                      </AlertDialogContent>
                    </AlertDialog>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      )}
    </div>
  );
}
