"use client";

import { useState } from "react";
import { useInventory } from "@/context/InventoryContext";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Alert, AlertDescription } from "@/components/ui/alert";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

interface OrderFormProps {
  orderId?: string;
  onClose: () => void;
}

type OrderItemForm = {
  productId: string;
  qty: number;
};

export function OrderForm({ orderId, onClose }: OrderFormProps) {
  const { products, orders, addOrder, updateOrder, loading, error: contextError } = useInventory();
  const existingOrder = orderId ? orders.find(o => o.id === orderId) : null;

  const [error, setError] = useState<string | null>(null);
  const [company, setCompany] = useState(existingOrder?.company || "");
  const [orderItems, setOrderItems] = useState<OrderItemForm[]>(
    existingOrder?.items.map(item => ({
      productId: item.productId,
      qty: item.qty,
    })) || [{ productId: "", qty: 1 }]
  );

  const handleAddItem = () => {
    setOrderItems([...orderItems, { productId: "", qty: 1 }]);
  };

  const handleRemoveItem = (index: number) => {
    setOrderItems(orderItems.filter((_, i) => i !== index));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    try {
      if (!company) {
        throw new Error("Company name is required");
      }

      if (orderItems.some(item => !item.productId)) {
        throw new Error("Please select products for all order items");
      }

      if (orderItems.some(item => item.qty <= 0)) {
        throw new Error("Quantity must be greater than 0 for all items");
      }

      const orderData = {
        company,
        items: orderItems.map(item => ({
          productId: item.productId,
          qty: item.qty
        }))
      };

      if (orderId) {
        await updateOrder(orderId, orderData);
      } else {
        await addOrder(orderData);
      }
      
      onClose();
    } catch (err) {
      setError(err instanceof Error ? err.message : "An error occurred");
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center p-6">
        <div className="flex items-center space-x-2 text-green-600">
          <div className="w-2 h-2 rounded-full animate-bounce [animation-delay:-0.3s] bg-green-600"></div>
          <div className="w-2 h-2 rounded-full animate-bounce [animation-delay:-0.15s] bg-green-600"></div>
          <div className="w-2 h-2 rounded-full animate-bounce bg-green-600"></div>
        </div>
      </div>
    );
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      {(error || contextError) && (
        <Alert variant="destructive" className="bg-red-50 border-red-200">
          <AlertDescription className="text-red-600 font-medium">
            {error || contextError}
          </AlertDescription>
        </Alert>
      )}

      <div className="space-y-2">
        <Label htmlFor="company" className="text-gray-700 font-semibold">Company Name</Label>
        <Input
          id="company"
          value={company}
          onChange={(e) => setCompany(e.target.value)}
          placeholder="Enter company name"
          className="border-gray-200 focus:border-green-300 focus:ring-2 focus:ring-green-100 transition-all duration-200"
          disabled={loading}
        />
      </div>

      <div className="space-y-4">
        <div className="flex justify-between items-center">
          <h3 className="text-lg font-semibold text-gray-800">Order Items</h3>
          <Button 
            type="button" 
            onClick={handleAddItem} 
            variant="outline"
            className="border-green-200 hover:border-green-300 hover:bg-green-50 text-green-600 transition-all duration-200"
            disabled={loading}
          >
            Add Item
          </Button>
        </div>

        {orderItems.map((item, index) => (
          <div key={index} className="space-y-2 p-6 border border-gray-100 rounded-xl bg-gradient-to-r from-green-50/30 to-white shadow-sm">
            <div className="flex justify-between items-start gap-4">
              <div className="flex-1 space-y-2">
                <Label className="text-gray-700 font-semibold">Product</Label>
                <Select
                  value={item.productId}
                  onValueChange={(value) =>
                    setOrderItems(orderItems.map((i, idx) =>
                      idx === index ? { ...i, productId: value } : i
                    ))
                  }
                  disabled={loading}
                >
                  <SelectTrigger className="border-gray-200 focus:border-green-300 focus:ring-2 focus:ring-green-100 transition-all duration-200">
                    <SelectValue placeholder="Select a product" />
                  </SelectTrigger>
                  <SelectContent>
                    {products.map((product) => (
                      <SelectItem key={product.id} value={product.id}>
                        {product.name} ({product.quantity} available)
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="w-24 space-y-2">
                <Label className="text-gray-700 font-semibold">Quantity</Label>
                <Input
                  type="number"
                  min="1"
                  value={item.qty}
                  onChange={(e) =>
                    setOrderItems(orderItems.map((i, idx) =>
                      idx === index ? { ...i, qty: parseInt(e.target.value) || 0 } : i
                    ))
                  }
                  className="border-gray-200 focus:border-green-300 focus:ring-2 focus:ring-green-100 transition-all duration-200"
                  disabled={loading}
                />
              </div>

              {orderItems.length > 1 && (
                <Button
                  type="button"
                  variant="destructive"
                  size="sm"
                  onClick={() => handleRemoveItem(index)}
                  className="bg-red-500 hover:bg-red-600 transition-colors duration-200 mt-6"
                  disabled={loading}
                >
                  Remove
                </Button>
              )}
            </div>
          </div>
        ))}
      </div>

      <div className="flex justify-end space-x-3 pt-4 border-t border-gray-100">
        <Button 
          type="button" 
          variant="outline" 
          onClick={onClose}
          className="border-gray-200 hover:border-gray-300 hover:bg-gray-50 transition-all duration-200"
          disabled={loading}
        >
          Cancel
        </Button>
        <Button 
          type="submit"
          className="bg-gradient-to-r from-green-600 to-green-500 hover:from-green-700 hover:to-green-600 transition-all duration-200 shadow-md hover:shadow-lg"
          disabled={loading}
        >
          {loading ? (
            <div className="flex items-center space-x-2">
              <div className="w-1.5 h-1.5 rounded-full animate-bounce [animation-delay:-0.3s] bg-white"></div>
              <div className="w-1.5 h-1.5 rounded-full animate-bounce [animation-delay:-0.15s] bg-white"></div>
              <div className="w-1.5 h-1.5 rounded-full animate-bounce bg-white"></div>
            </div>
          ) : (
            `${orderId ? 'Update' : 'Create'} Order`
          )}
        </Button>
      </div>
    </form>
  );
}
