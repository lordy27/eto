export type ProductFormData = {
  name: string;
  quantity: number;
  capacity: string;
  serial: string;
};

export interface Product extends ProductFormData {
  id: string;
  createdAt: Date;
  updatedAt: Date;
  orderItems?: OrderItem[];
}

export interface OrderItem {
  id: string;
  qty: number;
  productId: string;
  orderId: string;
  product: Product;
  order?: Order;
}

export interface Order {
  id: string;
  company: string;
  date: Date;
  createdAt: Date;
  updatedAt: Date;
  items: OrderItem[];
}
