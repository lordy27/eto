import type { Metadata } from "next";
import { Inter } from "next/font/google";
import "./globals.css";

const inter = Inter({ subsets: ["latin"] });

export const metadata: Metadata = {
  title: "JANNIEL BROTHERS DIGITECH CO. - Inventory System",
  description: "Monitor stocks, manage products, and track orders in real-time",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body className={`${inter.className} min-h-screen bg-gradient-to-r from-green-50 via-white to-green-50`}>
        <div className="relative flex min-h-screen flex-col">
          <header className="bg-gradient-to-r from-green-600 to-green-400 p-4 shadow-md">
            <div className="container mx-auto flex items-center justify-between">
              <h1 className="text-2xl font-bold text-white">JANNIEL BROTHERS DIGITECH CO.</h1>
              <nav>
                <ul className="flex space-x-4">
                  <li><a href="/" className="text-white hover:text-gray-200">Home</a></li>
                  <li><a href="/about" className="text-white hover:text-gray-200">About</a></li>
                </ul>
              </nav>
            </div>
          </header>
          <div className="hero-banner flex items-center justify-center text-white text-4xl font-bold p-12 bg-gradient-to-r from-green-600 to-green-400">
            Welcome to Our System
          </div>
          <div className="flex-1">{children}</div>
        </div>
      </body>
    </html>
  );
}
