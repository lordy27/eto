import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { PrismaClient } from "@prisma/client";

export async function PUT(
  request: Request,
  { params }: { params: { id: string } }
) {
  try {
    const body = await request.json();

    // Use a transaction to ensure atomic updates
    const updatedOrder = await prisma.$transaction(async (tx) => {
      // Get the existing order with its items
      const existingOrder = await tx.order.findUnique({
        where: { id: params.id },
        include: {
          items: {
            include: {
              product: true,
            },
          },
        },
      });

      if (!existingOrder) {
        throw new Error("Order not found");
      }

      // First, restore the quantities from the existing order
      for (const item of existingOrder.items) {
        await tx.product.update({
          where: { id: item.productId },
          data: { quantity: item.product.quantity + item.qty },
        });
      }

      // Then validate and update product quantities for the new order items
      for (const item of body.items) {
        const product = await tx.product.findUnique({
          where: { id: item.productId },
        });

        if (!product) {
          throw new Error(`Product not found with ID: ${item.productId}`);
        }

        if (product.quantity < item.qty) {
          throw new Error(
            `Insufficient stock for product ${product.name}. Available: ${product.quantity}, Requested: ${item.qty}`
          );
        }

        // Update product quantity
        await tx.product.update({
          where: { id: item.productId },
          data: { quantity: product.quantity - item.qty },
        });
      }

      // Delete existing order items
      await tx.orderItem.deleteMany({
        where: { orderId: params.id },
      });

      // Update the order and create new order items
      return await tx.order.update({
        where: { id: params.id },
        data: {
          company: body.company,
          items: {
            create: body.items.map((item: { productId: string; qty: number }) => ({
              productId: item.productId,
              qty: item.qty,
            })),
          },
        },
        include: {
          items: {
            include: {
              product: true,
            },
          },
        },
      });
    });

    return NextResponse.json(updatedOrder);
  } catch (error: any) {
    console.error("Update error:", error);
    return NextResponse.json(
      { error: error.message || "Failed to update order" },
      { status: 400 }
    );
  }
}

export async function DELETE(
  request: Request,
  { params }: { params: { id: string } }
) {
  try {
    // Use a transaction to ensure atomic updates
    await prisma.$transaction(async (tx) => {
      // Get the order with its items
      const order = await tx.order.findUnique({
        where: { id: params.id },
        include: {
          items: {
            include: {
              product: true,
            },
          },
        },
      });

      if (!order) {
        throw new Error("Order not found");
      }

      // Restore product quantities
      for (const item of order.items) {
        await tx.product.update({
          where: { id: item.productId },
          data: { quantity: item.product.quantity + item.qty },
        });
      }

      // Delete order items
      await tx.orderItem.deleteMany({
        where: { orderId: params.id },
      });

      // Delete the order
      await tx.order.delete({
        where: { id: params.id },
      });
    });

    return NextResponse.json({ message: "Order deleted successfully" });
  } catch (error: any) {
    console.error("Delete error:", error);
    return NextResponse.json(
      { error: error.message || "Failed to delete order" },
      { status: 400 }
    );
  }
}
