export type ProductFormData = {
  name: string;
  quantity: number;
  capacity: string;
  serial: string;
  capitalPrice: number;
  sellingPrice: number;
};

export interface Product extends ProductFormData {
  id: string;
  createdAt: Date;
  updatedAt: Date;
  orderItems?: OrderItem[];
}

export interface OrderItem {
  id: string;
  qty: number;
  profit: number;
  productId: string;
  orderId: string;
  product: Product;
  order?: Order;
}

export interface Order {
  id: string;
  company: string;
  date: Date;
  profit: number;
  createdAt: Date;
  updatedAt: Date;
  items: OrderItem[];
}
