"use client";

import { useState } from "react";
import { useInventory } from "@/context/InventoryContext";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { ProductFormData } from "@/types";

interface ProductFormProps {
  productId?: string;
  onClose: () => void;
}

export function ProductForm({ productId, onClose }: ProductFormProps) {
  const { products, addProduct, updateProduct, loading, error: contextError } = useInventory();
  const existingProduct = productId ? products.find(p => p.id === productId) : null;

  const [error, setError] = useState<string | null>(null);
  const [formData, setFormData] = useState<ProductFormData>({
    name: existingProduct?.name || '',
    quantity: existingProduct?.quantity || 0,
    capacity: existingProduct?.capacity || '',
    serial: existingProduct?.serial || '',
    capitalPrice: existingProduct?.capitalPrice || 0,
    sellingPrice: existingProduct?.sellingPrice || 0
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    try {
      if (!formData.name || !formData.capacity || !formData.serial) {
        throw new Error('All fields are required');
      }

      if (formData.quantity < 0) {
        throw new Error('Quantity must be a positive number');
      }

      if (formData.capitalPrice < 0 || formData.sellingPrice < 0) {
        throw new Error('Prices must be positive numbers');
      }

      if (formData.sellingPrice < formData.capitalPrice) {
        throw new Error('Selling price must be greater than capital price');
      }

      if (productId) {
        await updateProduct(productId, formData);
      } else {
        await addProduct(formData);
      }

      onClose();
    } catch (err) {
      setError(err instanceof Error ? err.message : "An error occurred");
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center p-6">
        <div className="flex items-center space-x-2 text-green-600">
          <div className="w-2 h-2 rounded-full animate-bounce [animation-delay:-0.3s] bg-green-600"></div>
          <div className="w-2 h-2 rounded-full animate-bounce [animation-delay:-0.15s] bg-green-600"></div>
          <div className="w-2 h-2 rounded-full animate-bounce bg-green-600"></div>
        </div>
      </div>
    );
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      {(error || contextError) && (
        <Alert variant="destructive" className="bg-red-50 border-red-200">
          <AlertDescription className="text-red-600 font-medium">
            {error || contextError}
          </AlertDescription>
        </Alert>
      )}

      <div className="space-y-2">
        <Label htmlFor="name" className="text-gray-700 font-semibold">Product Name</Label>
        <Input
          id="name"
          value={formData.name}
          onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
          placeholder="Enter product name"
          className="border-gray-200 focus:border-green-300 focus:ring-2 focus:ring-green-100 transition-all duration-200"
          disabled={loading}
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="quantity" className="text-gray-700 font-semibold">Quantity</Label>
        <Input
          id="quantity"
          type="number"
          value={formData.quantity}
          onFocus={(e) => e.target.select()}
          onChange={(e) => setFormData(prev => ({ ...prev, quantity: parseInt(e.target.value) || 0 }))}
          min="0"
          className="border-gray-200 focus:border-green-300 focus:ring-2 focus:ring-green-100 transition-all duration-200"
          disabled={loading}
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="capacity" className="text-gray-700 font-semibold">Capacity</Label>
        <Input
          id="capacity"
          value={formData.capacity}
          onChange={(e) => setFormData(prev => ({ ...prev, capacity: e.target.value }))}
          placeholder="Enter capacity"
          className="border-gray-200 focus:border-green-300 focus:ring-2 focus:ring-green-100 transition-all duration-200"
          disabled={loading}
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="serial" className="text-gray-700 font-semibold">Serial Number</Label>
        <Input
          id="serial"
          value={formData.serial}
          onChange={(e) => setFormData(prev => ({ ...prev, serial: e.target.value }))}
          placeholder="Enter serial number"
          className="border-gray-200 focus:border-green-300 focus:ring-2 focus:ring-green-100 transition-all duration-200"
          disabled={loading}
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="capitalPrice" className="text-gray-700 font-semibold">Capital Price</Label>
        <Input
          id="capitalPrice"
          type="number"
          value={formData.capitalPrice}
          onFocus={(e) => e.target.select()}
          onChange={(e) => setFormData(prev => ({ ...prev, capitalPrice: parseFloat(e.target.value) || 0 }))}
          min="0"
          step="0.01"
          className="border-gray-200 focus:border-green-300 focus:ring-2 focus:ring-green-100 transition-all duration-200"
          disabled={loading}
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="sellingPrice" className="text-gray-700 font-semibold">Selling Price</Label>
        <Input
          id="sellingPrice"
          type="number"
          value={formData.sellingPrice}
          onFocus={(e) => e.target.select()}
          onChange={(e) => setFormData(prev => ({ ...prev, sellingPrice: parseFloat(e.target.value) || 0 }))}
          min="0"
          step="0.01"
          className="border-gray-200 focus:border-green-300 focus:ring-2 focus:ring-green-100 transition-all duration-200"
          disabled={loading}
        />
      </div>

      <div className="flex justify-end space-x-3 pt-4 border-t border-gray-100">
        <Button 
          type="button" 
          variant="outline" 
          onClick={onClose}
          className="border-gray-200 hover:border-gray-300 hover:bg-gray-50 transition-all duration-200"
          disabled={loading}
        >
          Cancel
        </Button>
        <Button 
          type="submit"
          className="bg-gradient-to-r from-green-600 to-green-500 hover:from-green-700 hover:to-green-600 transition-all duration-200 shadow-md hover:shadow-lg"
          disabled={loading}
        >
          {loading ? (
            <div className="flex items-center space-x-2">
              <div className="w-1.5 h-1.5 rounded-full animate-bounce [animation-delay:-0.3s] bg-white"></div>
              <div className="w-1.5 h-1.5 rounded-full animate-bounce [animation-delay:-0.15s] bg-white"></div>
              <div className="w-1.5 h-1.5 rounded-full animate-bounce bg-white"></div>
            </div>
          ) : (
            `${productId ? 'Update' : 'Add'} Product`
          )}
        </Button>
      </div>
    </form>
  );
}
