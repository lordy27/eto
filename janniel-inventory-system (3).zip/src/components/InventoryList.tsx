"use client";

import { useState, ChangeEvent } from "react";
import { useInventory } from "@/context/InventoryContext";
import { Button } from "@/components/ui/button";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Input } from "@/components/ui/input";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { ProductForm } from "@/components/ProductForm";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";

export function InventoryList() {
  const { products, deleteProduct, loading, error } = useInventory();
  const [editProduct, setEditProduct] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState("");

  const filteredProducts = products.filter(product => 
    product.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    product.serial.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const totalInventoryValue = products.reduce(
    (total, product) => total + (product.quantity * product.capitalPrice), 
    0
  );

  const totalPotentialRevenue = products.reduce(
    (total, product) => total + (product.quantity * product.sellingPrice), 
    0
  );

  const totalPotentialProfit = products.reduce(
    (total, product) => total + (product.quantity * (product.sellingPrice - product.capitalPrice)), 
    0
  );

  if (error) {
    return (
      <Alert variant="destructive">
        <AlertDescription>{error}</AlertDescription>
      </Alert>
    );
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center py-8">
        <div className="text-muted-foreground animate-pulse">Loading products...</div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="bg-white rounded-xl shadow-lg p-6">
        <div className="space-y-6">
          <div className="flex justify-between items-start">
            <div>
              <h2 className="text-2xl font-bold bg-gradient-to-r from-green-600 to-green-400 bg-clip-text text-transparent">
                Products Inventory
              </h2>
              <p className="text-gray-500 mt-1">Manage your product catalog</p>
            </div>
            <Dialog>
              <DialogTrigger asChild>
                <Button className="bg-gradient-to-r from-green-600 to-green-500 hover:from-green-700 hover:to-green-600 transition-all duration-200 shadow-md hover:shadow-lg">
                  Add Product
                </Button>
              </DialogTrigger>
              <DialogContent className="bg-white rounded-xl shadow-2xl">
                <DialogHeader>
                  <DialogTitle className="text-2xl font-bold bg-gradient-to-r from-green-600 to-green-400 bg-clip-text text-transparent">
                    Add New Product
                  </DialogTitle>
                </DialogHeader>
                <ProductForm onClose={() => {}} />
              </DialogContent>
            </Dialog>
          </div>

          <div className="grid grid-cols-3 gap-4">
            <div className="bg-green-50 p-4 rounded-lg">
              <p className="text-sm text-green-600 font-medium">Total Inventory Value</p>
              <p className="text-2xl font-bold text-green-700">
                ₱{totalInventoryValue.toLocaleString()}
              </p>
            </div>
            <div className="bg-blue-50 p-4 rounded-lg">
              <p className="text-sm text-blue-600 font-medium">Potential Revenue</p>
              <p className="text-2xl font-bold text-blue-700">
                ₱{totalPotentialRevenue.toLocaleString()}
              </p>
            </div>
            <div className="bg-purple-50 p-4 rounded-lg">
              <p className="text-sm text-purple-600 font-medium">Potential Profit</p>
              <p className="text-2xl font-bold text-purple-700">
                ₱{totalPotentialProfit.toLocaleString()}
              </p>
            </div>
          </div>

          <div className="w-80">
            <div className="relative">
              <Input
                type="search"
                placeholder="Search products..."
                value={searchQuery}
                onChange={(e: ChangeEvent<HTMLInputElement>) => setSearchQuery(e.target.value)}
                className="pl-10 border-gray-200 focus:border-green-300 focus:ring-2 focus:ring-green-100 transition-all duration-200"
              />
              <svg
                className="absolute left-3 top-2.5 h-5 w-5 text-gray-400"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
                xmlns="http://www.w3.org/2000/svg"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth="2"
                  d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"
                />
              </svg>
            </div>
          </div>
        </div>
      </div>

      {products.length === 0 ? (
        <div className="bg-white rounded-xl shadow-lg p-12 text-center">
          <p className="text-gray-500 text-lg">
            No products yet. Add your first product to get started.
          </p>
        </div>
      ) : (
        <div className="bg-white rounded-xl shadow-lg p-6 overflow-hidden">
          <Table>
            <TableHeader>
              <TableRow className="bg-gradient-to-r from-green-50 to-white border-b-2 border-green-100">
                <TableHead className="font-bold text-green-600">Name</TableHead>
                <TableHead className="font-bold text-green-600">Quantity</TableHead>
                <TableHead className="font-bold text-green-600">Status</TableHead>
                <TableHead className="font-bold text-green-600">Capacity</TableHead>
                <TableHead className="font-bold text-green-600">Serial</TableHead>
                <TableHead className="font-bold text-green-600 text-right">Capital Price</TableHead>
                <TableHead className="font-bold text-green-600 text-right">Selling Price</TableHead>
                <TableHead className="font-bold text-green-600 text-right">Profit/Unit</TableHead>
                <TableHead className="font-bold text-green-600">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredProducts.map((product) => (
                <TableRow key={product.id} className="hover:bg-green-50 transition-colors duration-200">
                  <TableCell className="font-medium">{product.name}</TableCell>
                  <TableCell>{product.quantity}</TableCell>
                  <TableCell>
                    {product.quantity > 20 ? (
                      <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-sm font-medium bg-green-100 text-green-800">
                        In Stock
                      </span>
                    ) : product.quantity > 5 ? (
                      <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-sm font-medium bg-yellow-100 text-yellow-800">
                        Low Stock
                      </span>
                    ) : product.quantity > 0 ? (
                      <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-sm font-medium bg-orange-100 text-orange-800">
                        Critical Stock
                      </span>
                    ) : (
                      <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-sm font-medium bg-red-100 text-red-800">
                        Out of Stock
                      </span>
                    )}
                  </TableCell>
                  <TableCell>{product.capacity}</TableCell>
                  <TableCell>{product.serial}</TableCell>
                  <TableCell className="text-right">₱{product.capitalPrice.toLocaleString()}</TableCell>
                  <TableCell className="text-right">₱{product.sellingPrice.toLocaleString()}</TableCell>
                  <TableCell className="text-right text-green-600">
                    ₱{(product.sellingPrice - product.capitalPrice).toLocaleString()}
                  </TableCell>
                  <TableCell className="space-x-2">
                    <Dialog>
                      <DialogTrigger asChild>
                        <Button 
                          variant="outline" 
                          size="sm"
                          className="bg-white hover:bg-green-50 text-green-600 border-green-200 hover:border-green-300 transition-colors duration-200"
                        >
                          Edit
                        </Button>
                      </DialogTrigger>
                      <DialogContent className="bg-white rounded-xl shadow-2xl">
                        <DialogHeader>
                          <DialogTitle className="text-2xl font-bold bg-gradient-to-r from-green-600 to-green-400 bg-clip-text text-transparent">
                            Edit Product
                          </DialogTitle>
                        </DialogHeader>
                        <ProductForm
                          productId={product.id}
                          onClose={() => {}}
                        />
                      </DialogContent>
                    </Dialog>

                    <AlertDialog>
                      <AlertDialogTrigger asChild>
                        <Button 
                          variant="destructive" 
                          size="sm"
                          className="bg-red-500 hover:bg-red-600 transition-colors duration-200"
                        >
                          Delete
                        </Button>
                      </AlertDialogTrigger>
                      <AlertDialogContent className="bg-white rounded-xl shadow-2xl">
                        <AlertDialogHeader>
                          <AlertDialogTitle className="text-2xl font-bold text-red-600">
                            Are you sure?
                          </AlertDialogTitle>
                          <AlertDialogDescription className="text-gray-600">
                            This action cannot be undone. This will permanently delete
                            the product.
                          </AlertDialogDescription>
                        </AlertDialogHeader>
                        <AlertDialogFooter>
                          <AlertDialogCancel className="hover:bg-gray-100 transition-colors duration-200">
                            Cancel
                          </AlertDialogCancel>
                          <AlertDialogAction
                            onClick={() => deleteProduct(product.id)}
                            className="bg-red-500 hover:bg-red-600 transition-colors duration-200"
                          >
                            Delete
                          </AlertDialogAction>
                        </AlertDialogFooter>
                      </AlertDialogContent>
                    </AlertDialog>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      )}
    </div>
  );
}
