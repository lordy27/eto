const { exec, spawn } = require('child_process');

// Function to open URL in default browser
function openBrowser(url) {
  switch (process.platform) {
    case 'darwin':
      exec(`open ${url}`);
      break;
    case 'win32':
      exec(`start ${url}`);
      break;
    default:
      exec(`xdg-open ${url}`);
  }
}

// Start the Next.js development server
console.log('Starting development server...');
const server = spawn('npm', ['run', 'dev'], {
  stdio: 'inherit',
  shell: true
});

// Wait for server to start then open browser
setTimeout(() => {
  console.log('Opening browser...');
  openBrowser('http://localhost:8000');
}, 5000);

// Handle process termination
process.on('SIGINT', () => {
  server.kill();
  process.exit();
});
