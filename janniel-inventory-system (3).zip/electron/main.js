const { app, BrowserWindow } = require('electron');
const path = require('path');
const isDev = require('electron-is-dev');
const { spawn } = require('child_process');
let mainWindow;
let nextProcess;

async function startNextServer() {
    return new Promise((resolve, reject) => {
        nextProcess = spawn('npm', ['start'], {
            shell: true,
            stdio: 'inherit'
        });

        // Give the server some time to start
        setTimeout(() => {
            resolve();
        }, 3000);
    });
}

async function createWindow() {
    mainWindow = new BrowserWindow({
        width: 1200,
        height: 800,
        webPreferences: {
            nodeIntegration: true,
            contextIsolation: false
        }
    });

    if (isDev) {
        nextProcess = spawn('npm', ['run', 'dev'], {
            shell: true,
            stdio: 'inherit'
        });
        await new Promise(resolve => setTimeout(resolve, 2000)); // Wait for dev server
        mainWindow.loadURL('http://localhost:8000');
    } else {
        await startNextServer();
        mainWindow.loadURL('http://localhost:3000');
    }

    mainWindow.on('closed', function () {
        mainWindow = null;
        if (nextProcess) nextProcess.kill();
    });
}

app.whenReady().then(createWindow);

app.on('window-all-closed', function () {
    if (process.platform !== 'darwin') {
        if (nextProcess) nextProcess.kill();
        app.quit();
    }
});

app.on('activate', function () {
    if (mainWindow === null) createWindow();
});
