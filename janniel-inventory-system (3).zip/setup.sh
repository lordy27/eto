#!/bin/bash

# Install dependencies
npm install

# Generate Prisma client
npx prisma generate

# Push the database schema
npx prisma db push

echo "Setup complete! You can now run 'npm run dev' to start the application."
