"use client";

import React, { useEffect, useState } from "react";
import { Bar } from "react-chartjs-2";
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend,
  Filler,
} from "chart.js";
import { Alert, AlertDescription } from "@/components/ui/alert";

ChartJS.register(
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend,
  Filler
);

interface FastMovingReport {
  productId: string;
  productName: string;
  totalSold: number;
}

export function FastMovingReports() {
  const [data, setData] = useState<FastMovingReport[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    async function fetchData() {
      setLoading(true);
      setError(null);
      try {
        const res = await fetch("/api/reports/fast-moving");
        if (!res.ok) {
          throw new Error("Failed to fetch report data");
        }
        const json = await res.json();
        setData(json);
      } catch (err) {
        setError(err instanceof Error ? err.message : "Unknown error");
      } finally {
        setLoading(false);
      }
    }
    fetchData();
  }, []);

  const gradient = (ctx: CanvasRenderingContext2D, chartArea: any) => {
    const colorStart = "rgba(22, 163, 74, 0.8)"; // Tailwind green-600
    const colorEnd = "rgba(134, 239, 172, 0.8)"; // Tailwind green-300
    const gradientFill = ctx.createLinearGradient(0, chartArea.bottom, 0, chartArea.top);
    gradientFill.addColorStop(0, colorStart);
    gradientFill.addColorStop(1, colorEnd);
    return gradientFill;
  };

  const chartData = {
    labels: data.map((item) => item.productName),
    datasets: [
      {
        label: "Total Sold",
        data: data.map((item) => item.totalSold),
        backgroundColor: function (context: any) {
          const chart = context.chart;
          const { ctx, chartArea } = chart;

          if (!chartArea) {
            // This case happens on initial chart load
            return undefined;
          }
          return gradient(ctx, chartArea) ?? undefined;
        },
        borderRadius: 8,
        borderSkipped: false,
        fill: true,
        tension: 0.4,
        hoverBackgroundColor: "rgba(22, 163, 74, 1)",
        hoverBorderColor: "rgba(22, 163, 74, 1)",
        hoverBorderWidth: 2,
      },
    ],
  };

  const options = {
    responsive: true,
    animation: {
      duration: 1200,
      easing: "easeOutQuart" as const,
    },
    plugins: {
      legend: {
        position: "top" as const,
        labels: {
          font: {
            size: 14,
            weight: "bold" as const,
          },
        },
      },
      title: {
        display: true,
        text: "Top 10 Fast Moving Products",
        font: {
          size: 20,
          weight: "bold" as const,
        },
      },
      tooltip: {
        enabled: true,
        backgroundColor: "rgba(22, 163, 74, 0.95)",
        titleFont: {
          size: 16,
          weight: "bold" as const,
        },
        bodyFont: {
          size: 14,
        },
        cornerRadius: 8,
        padding: 10,
      },
    },
    scales: {
      x: {
        grid: {
          display: false,
        },
        ticks: {
          font: {
            size: 14,
            weight: "bold" as const,
          },
          color: "#16a34a",
        },
      },
      y: {
        beginAtZero: true,
        grid: {
          color: "rgba(22, 163, 74, 0.1)",
          borderDash: [6, 6],
        },
        ticks: {
          font: {
            size: 14,
            weight: "bold" as const,
          },
          color: "#16a34a",
          stepSize: 10,
        },
      },
    },
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center p-6">
        <div className="flex items-center space-x-2 text-green-600">
          <div className="w-2 h-2 rounded-full animate-bounce [animation-delay:-0.3s] bg-green-600"></div>
          <div className="w-2 h-2 rounded-full animate-bounce [animation-delay:-0.15s] bg-green-600"></div>
          <div className="w-2 h-2 rounded-full animate-bounce bg-green-600"></div>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <Alert variant="destructive">
        <AlertDescription>{error}</AlertDescription>
      </Alert>
    );
  }

  return (
    <div className="max-w-4xl mx-auto p-6 bg-gradient-to-r from-green-50 via-white to-green-50 rounded-xl shadow-xl">
      <div className="mb-4">
        <h2 className="text-2xl font-bold text-green-700">Fast Moving Products Report</h2>
        <p className="text-sm text-green-500">Top 10 products by total quantity sold</p>
      </div>
      <div className="bg-white p-6 rounded-lg shadow-md">
        <Bar options={options} data={chartData} />
      </div>
    </div>
  );
}
