# JANNIEL BROTHERS DIGITECH CO. - Inventory System

A modern inventory management system built with Next.js, Prisma, and Tailwind CSS. Available as both a web application and a Windows desktop app.

## Features

- Product inventory management
- Order tracking
- Stock level monitoring with status indicators
- Fast-moving products reports
- Modern UI with dark mode support

## Installation Options

### Option 1: Windows Desktop App

1. Download the installer (JannielBrothersInventory-Setup.exe) from the releases
2. Run the installer
3. Choose your installation directory
4. Follow the installation wizard
5. Launch the application from your desktop shortcut or start menu

### Option 2: Development Setup

2. Make the setup script executable and run it:
```bash
chmod +x setup.sh
./setup.sh
```

Or manually run these commands:
```bash
# Install dependencies
npm install

# Generate Prisma client
npx prisma generate

# Push the database schema
npx prisma db push
```

3. Start the development server:
```bash
npm run dev
```

4. Open [http://localhost:3000](http://localhost:3000) in your browser

## Notes

- The project uses SQLite as the database, which is stored in `prisma/dev.db`. When you run the setup script, it will create a fresh database with the schema, but without any data. You'll need to add your products and orders through the UI.
- The Windows app is a standalone desktop application that includes all necessary dependencies.

## Tech Stack & Tools

- Next.js 14 (Web Framework)
- Prisma (SQLite Database)
- Tailwind CSS (Styling)
- shadcn/ui (UI Components)
- TypeScript (Language)
- Electron (Desktop App Framework)
- electron-builder (Windows Installer)

## Building the Windows App

1. Build the Next.js application:
```bash
npm run build
```

2. Create the Windows installer:
```bash
npm run build-windows
```

The installer will be created in the `dist` folder.

## System Requirements (Windows App)

- Windows 7 or later
- 4GB RAM minimum
- 500MB free disk space
