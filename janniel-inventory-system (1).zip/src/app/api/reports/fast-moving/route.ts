import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

export async function GET() {
  try {
    const fastMoving = await prisma.orderItem.groupBy({
      by: ['productId'],
      _sum: {
        qty: true,
      },
      orderBy: {
        _sum: {
          qty: 'desc',
        },
      },
      take: 10,
    });

    // Fetch product names for the productIds
    const productIds = fastMoving.map((item: { productId: string }) => item.productId);
    const products = await prisma.product.findMany({
      where: {
        id: { in: productIds },
      },
      select: {
        id: true,
        name: true,
      },
    });

    // Map product names to fastMoving data
    const result = fastMoving.map((item: { productId: string; _sum: { qty: number | null } }) => {
      const product = products.find((p: { id: string }) => p.id === item.productId);
      return {
        productId: item.productId,
        productName: product?.name || 'Unknown',
        totalSold: item._sum.qty || 0,
      };
    });

    return NextResponse.json(result);
  } catch (error) {
    return NextResponse.json({ error: 'Failed to fetch fast moving products' }, { status: 500 });
  }
}
