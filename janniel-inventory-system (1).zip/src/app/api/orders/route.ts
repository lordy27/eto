import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { PrismaClient } from "@prisma/client";

export async function GET() {
  try {
    const orders = await prisma.order.findMany({
      include: {
        items: {
          include: {
            product: true,
          },
        },
      },
    });
    return NextResponse.json(orders);
  } catch (error) {
    return NextResponse.json({ error: "Failed to fetch orders" }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json();

    // Use a transaction to ensure atomic updates
    const newOrder = await prisma.$transaction(async (tx) => {
      // Validate and update product quantities
      for (const item of body.items) {
        const product = await tx.product.findUnique({
          where: { id: item.productId },
        });

        if (!product) {
          throw new Error(`Product not found with ID: ${item.productId}`);
        }

        if (product.quantity < item.qty) {
          throw new Error(
            `Insufficient stock for product ${product.name}. Available: ${product.quantity}, Requested: ${item.qty}`
          );
        }

        // Update product quantity
        await tx.product.update({
          where: { id: item.productId },
          data: { quantity: product.quantity - item.qty },
        });
      }

      // Create the order with its items
      return await tx.order.create({
        data: {
          company: body.company,
          items: {
            create: body.items.map((item: any) => ({
              qty: item.qty,
              product: { connect: { id: item.productId } },
            })),
          },
        },
        include: {
          items: {
            include: {
              product: true,
            },
          },
        },
      });
    });

    return NextResponse.json(newOrder, { status: 201 });
  } catch (error: any) {
    return NextResponse.json(
      { error: error.message || "Failed to create order" },
      { status: 400 }
    );
  }
}
