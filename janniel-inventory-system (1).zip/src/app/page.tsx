"use client";

import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { InventoryProvider } from "@/context/InventoryContext";
import { InventoryList } from "@/components/InventoryList";
import { OrdersList } from "@/components/OrdersList";
import { FastMovingReports } from "@/components/FastMovingReports";

export default function Home() {
  return (
    <InventoryProvider>
      <main className="container mx-auto p-8 space-y-8">
        <div className="bg-gradient-to-r from-green-600 to-green-400 rounded-xl shadow-lg p-8 mb-8">
          <div className="flex flex-col space-y-4 w-full">
            <p className="text-white/90 text-xl text-center font-semibold">
              Welcome to our inventory management system. Monitor stocks, manage products, and track orders in real-time.
            </p>
          </div>
        </div>

        <Tabs defaultValue="inventory" className="w-full">
          <TabsList className="grid w-full grid-cols-3 gap-2 bg-gradient-to-r from-green-100 to-green-50 p-1 rounded-lg">
            <TabsTrigger value="inventory" className="data-[state=active]:bg-white data-[state=active]:text-green-600 data-[state=active]:shadow-md">
              Inventory
            </TabsTrigger>
            <TabsTrigger value="orders" className="data-[state=active]:bg-white data-[state=active]:text-green-600 data-[state=active]:shadow-md">
              Orders
            </TabsTrigger>
            <TabsTrigger value="reports" className="data-[state=active]:bg-white data-[state=active]:text-green-600 data-[state=active]:shadow-md">
              Reports
            </TabsTrigger>
          </TabsList>
          
          <TabsContent value="inventory" className="space-y-4">
            <InventoryList />
          </TabsContent>
          
          <TabsContent value="orders" className="space-y-4">
            <OrdersList />
          </TabsContent>

          <TabsContent value="reports" className="space-y-4">
            <FastMovingReports />
          </TabsContent>
        </Tabs>
      </main>
    </InventoryProvider>
  );
}
