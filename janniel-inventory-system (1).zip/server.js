const express = require('express');
const next = require('next');
const { PrismaClient } = require('@prisma/client');

const dev = process.env.NODE_ENV !== 'production';
const app = next({ dev });
const handle = app.getRequestHandler();
const prisma = new PrismaClient();

const port = process.env.PORT || 8000;

app.prepare().then(() => {
  const server = express();
  
  // Parse JSON bodies
  server.use(express.json());

  // API Routes
  // Get all products
  server.get('/api/products', async (req, res) => {
    try {
      const products = await prisma.product.findMany();
      res.json(products);
    } catch (error) {
      res.status(500).json({ error: 'Error fetching products' });
    }
  });

  // Create a product
  server.post('/api/products', async (req, res) => {
    try {
      const { name, quantity, capacity, serialNumber } = req.body;
      const product = await prisma.product.create({
        data: {
          name,
          quantity: parseInt(quantity),
          capacity,
          serialNumber
        }
      });
      res.json(product);
    } catch (error) {
      res.status(500).json({ error: 'Error creating product' });
    }
  });

  // Get all orders
  server.get('/api/orders', async (req, res) => {
    try {
      const orders = await prisma.order.findMany({
        include: {
          product: true
        }
      });
      res.json(orders);
    } catch (error) {
      res.status(500).json({ error: 'Error fetching orders' });
    }
  });

  // Create an order
  server.post('/api/orders', async (req, res) => {
    try {
      const { productId, quantity, orderType } = req.body;
      const order = await prisma.order.create({
        data: {
          productId,
          quantity: parseInt(quantity),
          orderType
        },
        include: {
          product: true
        }
      });
      res.json(order);
    } catch (error) {
      res.status(500).json({ error: 'Error creating order' });
    }
  });

  // Get fast moving reports
  server.get('/api/reports/fast-moving', async (req, res) => {
    try {
      const orders = await prisma.order.groupBy({
        by: ['productId'],
        _sum: {
          quantity: true
        },
        orderBy: {
          _sum: {
            quantity: 'desc'
          }
        },
        take: 5
      });
      res.json(orders);
    } catch (error) {
      res.status(500).json({ error: 'Error generating report' });
    }
  });

  // Handle all other routes with Next.js
  server.all('*', (req, res) => {
    return handle(req, res);
  });

  server.listen(port, (err) => {
    if (err) throw err;
    console.log(`> Ready on http://localhost:${port}`);
  });
}).catch((ex) => {
  console.error(ex.stack);
  process.exit(1);
});
